# Candle Implementation Spec

## Purpose

Create a slender PCB candle lamp that is visually expressive enough to exercise
KiCad-aware agents and validation tools without the complexity of a multi-sheet
or microcontroller-driven design.

## PCB

- Outline: `215 mm x 20 mm`
- Thickness: `1.6 mm FR4`
- Copper: `1 oz`, 2-layer
- Finish target: `ENIG`
- Soldermask target: `red`
- Front silkscreen: none
- Back silkscreen: minimal grouped reference text only

### Zone A: top light engine

- `10x` warm-white `0805` LEDs, nominal `2700 K`
- `10x` `300R` `0805` resistors, one per LED
- LEDs arranged as `5 x 2`
- LED pitch target from the concept: `3 mm` horizontal, `4 mm` vertical
- Implemented manufacturable pitch: approximately `4 mm` horizontal,
  `5 mm` vertical with slightly staggered resistor centering
- Resistors tucked immediately below their corresponding LEDs

### Zone B: mid decorative cluster

- `2x` warm-white `0603` LEDs
- `2x` `1k` `0603` resistors
- `1x` unpopulated `SOIC-8` decorative footprint

### Zone C: front copper art

- Exposed `F.Cu` vein traces with matching `F.Mask` openings
- Copper art tied to `GND` through vias into a backside ground plane

### Zone D: base interface

- `2x` backside pogo landing pads
- Pitch target retained at `2.54 mm`
- Implemented copper diameter: `2.0 mm` to avoid overlap
- Polarity marker implemented in silkscreen rather than copper
- `2x` clamp holes near the lower edge

## Enclosure Notes

- Base target: `54 mm x 54 mm x 24 mm`
- Sleeve target: `OD 36 mm`, height `190 mm`
- PCB extends roughly `12 mm` above sleeve top
- The base contains `3x AAA`, a side slide switch, and two pogo pins feeding the
  PCB directly

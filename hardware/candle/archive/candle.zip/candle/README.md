# Candle

`candle/` is a compact KiCad test project for the agent and CLI workflows in this
workspace. It implements a PCB-as-art candle lamp: a tall red PCB with a warm
white LED crown, a slim decorative midsection, backside pogo-pad power input,
and enclosure dimensions captured for a simple AAA-powered base and sleeve.

Implemented assumptions:

- The board is a single `215 mm x 20 mm` 2-layer PCB with `R2 mm` top corners.
- Top light engine: `10x` warm-white `0805` LEDs, each with its own `300R`
  resistor, arranged as a `5 x 2` cluster.
- The top LED cluster is spread slightly wider than the original pitch note so
  stock `0805` footprints and individual return nets stay DRC-clean. The
  implemented layout uses roughly `4 mm` horizontal pitch and `5 mm` vertical
  pitch at the PCB level.
- Mid accent lights: `2x` warm-white `0603` LEDs, each with its own `1k`
  resistor. The original spec text implied one shared resistor, but the stated
  current budget only makes sense with one resistor per LED, so that is what is
  implemented here.
- The back-side pogo interface keeps the requested `2.54 mm` pitch, but the pad
  copper diameter is reduced to `2.0 mm`. Two separate `3.0 mm` circular pads
  at `2.54 mm` pitch would overlap and short.
- The polarity marker next to the pogo pad is implemented as back silkscreen
  instead of copper so the pad area remains DRC-clean.
- The mounting holes use the stock KiCad `3.2 mm M3` footprint as a close
  manufacturable match to the requested `3.0 mm` holes.

Contents:

- `candle.kicad_pro`: KiCad project file
- `candle.kicad_sch`: generated schematic
- `candle.kicad_pcb`: generated PCB
- `candle.pretty/`: local custom footprint library for the pogo connector
- `specs/candle_spec.md`: implementation-oriented copy of the build spec
- `tools/generate_candle.py`: repeatable generator for the schematic and board
- `tools/export_candle.py`: repeatable export helper for PDFs, BOMs, netlist,
  position data, Gerbers, drill, and a zipped fabrication bundle

Regeneration:

```bash
PYTHONPATH="/Applications/KiCad/KiCad.app/Contents/Frameworks/python/site-packages" \
/Applications/KiCad/KiCad.app/Contents/Frameworks/Python.framework/Versions/3.9/bin/python3 \
  tools/generate_candle.py
```

Export package:

```bash
python3 tools/export_candle.py
```

Validation:

```bash
/Applications/KiCad/KiCad.app/Contents/MacOS/kicad-cli sch erc \
  --format json \
  -o outputs/candle-erc.json \
  candle.kicad_sch

/Applications/KiCad/KiCad.app/Contents/MacOS/kicad-cli pcb drc \
  --format json \
  -o outputs/candle-drc.json \
  candle.kicad_pcb
```

Current validation state after generation:

- Schematic ERC: clean
- PCB DRC: clean

The schematic uses proper KiCad `power:` symbols plus one explicit `VCC` / `GND`
label pair at the input connector. That keeps ERC clean while still giving the
local CLI-Anything KiCad parser two named rails to report during quick net
inspection.

Artifact outputs:

- `outputs/docs/`: schematic PDF plus front/back board PDFs
- `outputs/fabrication/candle-bom-raw.csv`: direct KiCad schematic BOM export
- `outputs/fabrication/candle-assembly-bom.csv`: curated populated-parts BOM
- `outputs/fabrication/candle-pos.csv`: populated SMD placement CSV
- `outputs/fabrication/gerbers/`: Gerber plots
- `outputs/fabrication/drill/`: Excellon drill files, drill map, and report
- `outputs/fabrication/candle-fabrication-bundle.zip`: packaged fabrication set

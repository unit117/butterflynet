# Candle Assembly Notes

- `U1` is decorative only. It is marked DNP on the PCB and is excluded from placement output.
- `J1` is an integrated copper landing pattern for spring pogo pins in the base, not a separate PCB-mounted connector.
- `H1` and `H2` are mechanical clamp holes for the sleeve interface and are not assembly-line components.
- `candle-pos.csv` includes only populated SMD parts.

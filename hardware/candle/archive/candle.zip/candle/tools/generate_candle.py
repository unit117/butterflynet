#!/usr/bin/env python3
"""Generate the Candle schematic and PCB from the local implementation spec."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
import tempfile
from pathlib import Path

try:
    import wx  # type: ignore
except ImportError:
    wx = None

try:
    import pcbnew  # type: ignore
except ImportError as exc:  # pragma: no cover - environment guard
    raise SystemExit(
        "pcbnew is unavailable. Run this script with KiCad's bundled Python."
    ) from exc

WX_APP = None
if wx is not None:
    try:
        WX_APP = wx.GetApp() or wx.App(False)
    except Exception:
        WX_APP = None


PROJECT_NAME = "candle"
PROJECT_DIR = Path(__file__).resolve().parents[1]
REPO_ROOT = PROJECT_DIR.parent
SCHEMATIC_PATH = PROJECT_DIR / f"{PROJECT_NAME}.kicad_sch"
BOARD_PATH = PROJECT_DIR / f"{PROJECT_NAME}.kicad_pcb"
OUTPUTS_DIR = PROJECT_DIR / "outputs"
SCHEMATIC_TOOL = REPO_ROOT / "demo-fixtures" / "portable-kit" / "tools" / "schematic_architect.py"
KICAD_CLI = Path("/Applications/KiCad/KiCad.app/Contents/MacOS/kicad-cli")

FOOTPRINT_LIBS = {
    "LED_SMD": "/Applications/KiCad/KiCad.app/Contents/SharedSupport/footprints/LED_SMD.pretty",
    "MountingHole": "/Applications/KiCad/KiCad.app/Contents/SharedSupport/footprints/MountingHole.pretty",
    "Package_SO": "/Applications/KiCad/KiCad.app/Contents/SharedSupport/footprints/Package_SO.pretty",
    "Resistor_SMD": "/Applications/KiCad/KiCad.app/Contents/SharedSupport/footprints/Resistor_SMD.pretty",
    "candle": str(PROJECT_DIR / "candle.pretty"),
}

BOARD_WIDTH_MM = 20.0
BOARD_HEIGHT_MM = 215.0
OUTLINE_RADIUS_MM = 2.0

VCC_RAIL_X = 10.0
VCC_RAIL_Y0 = 110.0
VCC_RAIL_Y1 = 210.0
VCC_TRUNK_X = 13.0


def run(cmd: list[str], cwd: Path | None = None) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(cmd, cwd=cwd, text=True, capture_output=True)
    if result.returncode != 0:
        raise RuntimeError(
            f"Command failed: {' '.join(cmd)}\nSTDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}"
        )
    return result


def mm_point(x_mm: float, y_mm: float) -> pcbnew.VECTOR2I:
    return pcbnew.VECTOR2I_MM(x_mm, y_mm)


def to_mm(point: pcbnew.VECTOR2I) -> tuple[float, float]:
    return round(pcbnew.ToMM(point.x), 4), round(pcbnew.ToMM(point.y), 4)


def branch_defs() -> list[dict]:
    branches: list[dict] = []
    top_rows = [210.0, 205.0, 200.0, 195.0, 190.0]
    columns = (
        {
            "led_x": 8.0,
            "res_x": 7.0,
            "side": "left",
            "led_rot": 0.0,
            "res_rot": 180.0,
        },
        {
            "led_x": 12.0,
            "res_x": 13.0,
            "side": "right",
            "led_rot": 180.0,
            "res_rot": 0.0,
        },
    )

    ref_index = 1
    for y in top_rows:
        for col in columns:
            branches.append(
                {
                    "dref": f"D{ref_index}",
                    "rref": f"R{ref_index}",
                    "net": f"LED{ref_index}_RET",
                    "side": col["side"],
                    "led_x": col["led_x"],
                    "res_x": col["res_x"],
                    "led_y": y,
                    "res_y": y - 2.6,
                    "led_rot": col["led_rot"],
                    "res_rot": col["res_rot"],
                    "led_value": "WW_2700K",
                    "res_value": "300R",
                    "led_fp": "LED_SMD:LED_0805_2012Metric",
                    "res_fp": "Resistor_SMD:R_0805_2012Metric",
                }
            )
            ref_index += 1

    branches.extend(
        [
            {
                "dref": "D11",
                "rref": "R11",
                "net": "LED11_RET",
                "side": "left",
                "led_x": 7.0,
                "res_x": 6.2,
                "led_y": 149.0,
                "res_y": 146.3,
                "led_rot": 0.0,
                "res_rot": 180.0,
                "led_value": "WW_2700K",
                "res_value": "1k",
                "led_fp": "LED_SMD:LED_0603_1608Metric",
                "res_fp": "Resistor_SMD:R_0603_1608Metric",
            },
            {
                "dref": "D12",
                "rref": "R12",
                "net": "LED12_RET",
                "side": "right",
                "led_x": 13.0,
                "res_x": 13.8,
                "led_y": 121.0,
                "res_y": 118.3,
                "led_rot": 180.0,
                "res_rot": 0.0,
                "led_value": "WW_2700K",
                "res_value": "1k",
                "led_fp": "LED_SMD:LED_0603_1608Metric",
                "res_fp": "Resistor_SMD:R_0603_1608Metric",
            },
        ]
    )
    return branches


def schematic_branch_layout() -> dict[str, tuple[float, float]]:
    layout: dict[str, tuple[float, float]] = {}
    x_positions = [86.36, 137.16]
    y_positions = [40.64, 71.12, 101.6, 132.08, 162.56]
    index = 1
    for y in y_positions:
        for x in x_positions:
            layout[f"D{index}"] = (x, y)
            index += 1
    layout["D11"] = (213.36, 81.28)
    layout["D12"] = (259.08, 132.08)
    return layout


def footprint_parts(footprint: str) -> tuple[str, str]:
    lib, name = footprint.split(":", 1)
    return lib, name


def add_outline(board: pcbnew.BOARD) -> None:
    edge = board.GetLayerID("Edge.Cuts")
    width = pcbnew.FromMM(0.05)

    for x1, y1, x2, y2 in (
        (0.0, 0.0, BOARD_WIDTH_MM, 0.0),
        (0.0, 0.0, 0.0, BOARD_HEIGHT_MM - OUTLINE_RADIUS_MM),
        (BOARD_WIDTH_MM, 0.0, BOARD_WIDTH_MM, BOARD_HEIGHT_MM - OUTLINE_RADIUS_MM),
        (OUTLINE_RADIUS_MM, BOARD_HEIGHT_MM, BOARD_WIDTH_MM - OUTLINE_RADIUS_MM, BOARD_HEIGHT_MM),
    ):
        shape = pcbnew.PCB_SHAPE(board)
        shape.SetShape(pcbnew.S_SEGMENT)
        shape.SetLayer(edge)
        shape.SetWidth(width)
        shape.SetStart(mm_point(x1, y1))
        shape.SetEnd(mm_point(x2, y2))
        board.Add(shape)

    for start, mid, end in (
        ((0.0, BOARD_HEIGHT_MM - OUTLINE_RADIUS_MM), (0.5858, BOARD_HEIGHT_MM - 0.5858), (OUTLINE_RADIUS_MM, BOARD_HEIGHT_MM)),
        ((BOARD_WIDTH_MM, BOARD_HEIGHT_MM - OUTLINE_RADIUS_MM), (BOARD_WIDTH_MM - 0.5858, BOARD_HEIGHT_MM - 0.5858), (BOARD_WIDTH_MM - OUTLINE_RADIUS_MM, BOARD_HEIGHT_MM)),
    ):
        shape = pcbnew.PCB_SHAPE(board)
        shape.SetShape(pcbnew.S_ARC)
        shape.SetLayer(edge)
        shape.SetWidth(width)
        shape.SetArcGeometry(mm_point(*start), mm_point(*mid), mm_point(*end))
        board.Add(shape)


def configure_board_setup(board: pcbnew.BOARD) -> None:
    board.SetCopperLayerCount(2)
    ds = board.GetDesignSettings()
    ds.m_HoleClearance = pcbnew.FromMM(0.2)
    ds.m_MinThroughDrill = pcbnew.FromMM(0.2)
    ds.m_ViasMinSize = pcbnew.FromMM(0.55)
    ds.m_MinThroughDrill = pcbnew.FromMM(0.25)
    ds.m_CopperEdgeClearance = pcbnew.FromMM(0.25)
    ds.m_SolderMaskExpansion = pcbnew.FromMM(0.0)
    ds.m_TrackMinWidth = pcbnew.FromMM(0.18)


def ensure_nets(board: pcbnew.BOARD, names: list[str]) -> dict[str, pcbnew.NETINFO_ITEM]:
    result: dict[str, pcbnew.NETINFO_ITEM] = {}
    for name in names:
        existing = board.FindNet(name)
        if existing:
            result[name] = existing
            continue
        net = pcbnew.NETINFO_ITEM(board, name)
        board.Add(net)
        result[name] = net
    return result


def load_footprint(
    board: pcbnew.BOARD,
    footprint: str,
    ref: str,
    value: str,
    x_mm: float,
    y_mm: float,
    rot_deg: float,
    *,
    backside: bool = False,
) -> pcbnew.FOOTPRINT:
    lib, name = footprint_parts(footprint)
    fp = pcbnew.FootprintLoad(FOOTPRINT_LIBS[lib], name)
    if fp is None:
        raise RuntimeError(f"Failed to load footprint {footprint}")
    fp.SetReference(ref)
    fp.SetValue(value)
    fp.SetPosition(mm_point(x_mm, y_mm))
    fp.SetOrientationDegrees(rot_deg)
    board.Add(fp)
    if backside and fp.GetLayer() != board.GetLayerID("B.Cu"):
        fp.Flip(fp.GetPosition(), False)
        fp.SetOrientationDegrees(rot_deg)
    return fp


def mute_footprint_text(board: pcbnew.BOARD, fp: pcbnew.FOOTPRINT) -> None:
    f_silk = board.GetLayerID("F.Silkscreen")
    b_silk = board.GetLayerID("B.Silkscreen")
    f_fab = board.GetLayerID("F.Fab")
    b_fab = board.GetLayerID("B.Fab")
    fp.Reference().SetVisible(False)
    fp.Value().SetVisible(False)
    for item in fp.GraphicalItems():
        if item.GetLayer() == f_silk:
            item.SetLayer(f_fab)
        elif item.GetLayer() == b_silk:
            item.SetLayer(b_fab)


def add_track(
    board: pcbnew.BOARD,
    net: pcbnew.NETINFO_ITEM,
    layer: str,
    start: tuple[float, float],
    end: tuple[float, float],
    width_mm: float,
) -> None:
    track = pcbnew.PCB_TRACK(board)
    track.SetStart(mm_point(*start))
    track.SetEnd(mm_point(*end))
    track.SetWidth(pcbnew.FromMM(width_mm))
    track.SetLayer(board.GetLayerID(layer))
    track.SetNet(net)
    board.Add(track)


def add_manhattan(
    board: pcbnew.BOARD,
    net: pcbnew.NETINFO_ITEM,
    layer: str,
    start: tuple[float, float],
    end: tuple[float, float],
    width_mm: float,
) -> None:
    if round(start[0], 4) == round(end[0], 4) or round(start[1], 4) == round(end[1], 4):
        add_track(board, net, layer, start, end, width_mm)
        return
    mid = (start[0], end[1])
    add_track(board, net, layer, start, mid, width_mm)
    add_track(board, net, layer, mid, end, width_mm)


def add_via(
    board: pcbnew.BOARD,
    net: pcbnew.NETINFO_ITEM,
    at: tuple[float, float],
    *,
    drill_mm: float = 0.3,
    diameter_mm: float = 0.7,
) -> None:
    via = pcbnew.PCB_VIA(board)
    via.SetNet(net)
    via.SetPosition(mm_point(*at))
    via.SetDrill(pcbnew.FromMM(drill_mm))
    via.SetWidth(pcbnew.FromMM(diameter_mm))
    via.SetLayerPair(board.GetLayerID("F.Cu"), board.GetLayerID("B.Cu"))
    board.Add(via)


def add_mask_segment(board: pcbnew.BOARD, start: tuple[float, float], end: tuple[float, float], width_mm: float) -> None:
    shape = pcbnew.PCB_SHAPE(board)
    shape.SetShape(pcbnew.S_SEGMENT)
    shape.SetLayer(board.GetLayerID("F.Mask"))
    shape.SetStart(mm_point(*start))
    shape.SetEnd(mm_point(*end))
    shape.SetWidth(pcbnew.FromMM(width_mm))
    board.Add(shape)


def add_board_text(
    board: pcbnew.BOARD,
    text_value: str,
    at: tuple[float, float],
    layer: str,
    *,
    size_mm: float = 0.9,
    thickness_mm: float = 0.15,
) -> None:
    text = pcbnew.PCB_TEXT(board)
    text.SetText(text_value)
    text.SetLayer(board.GetLayerID(layer))
    text.SetPosition(mm_point(*at))
    text.SetTextSize(pcbnew.VECTOR2I_MM(size_mm, size_mm))
    text.SetTextThickness(pcbnew.FromMM(thickness_mm))
    if layer.startswith("B."):
        text.SetMirrored(True)
    board.Add(text)


def add_rect_zone(
    board: pcbnew.BOARD,
    net: pcbnew.NETINFO_ITEM,
    layer_name: str,
    rect_mm: tuple[float, float, float, float],
    zone_name: str,
) -> None:
    x1, y1, x2, y2 = rect_mm
    zone = board.AddArea(
        None,
        net.GetNetCode(),
        board.GetLayerID(layer_name),
        mm_point(x1, y1),
        pcbnew.ZONE_BORDER_DISPLAY_STYLE_DIAGONAL_EDGE,
    )
    outline = zone.Outline()
    outline.Append(mm_point(x2, y1))
    outline.Append(mm_point(x2, y2))
    outline.Append(mm_point(x1, y2))
    zone.SetNet(net)
    zone.SetZoneName(zone_name)
    zone.SetMinThickness(pcbnew.FromMM(0.2))
    zone.SetThermalReliefGap(pcbnew.FromMM(0.25))
    zone.SetThermalReliefSpokeWidth(pcbnew.FromMM(0.3))
    zone.SetPadConnection(pcbnew.ZONE_CONNECTION_THERMAL)


def pad(fp: pcbnew.FOOTPRINT, number: str) -> pcbnew.PAD:
    found = fp.FindPadByNumber(number)
    if found is None:
        raise RuntimeError(f"Footprint {fp.GetReference()} missing pad {number}")
    return found


def assign_pad_net(fp: pcbnew.FOOTPRINT, number: str, net: pcbnew.NETINFO_ITEM) -> pcbnew.PAD:
    found = pad(fp, number)
    found.SetNet(net)
    return found


def write_schematic(branches: list[dict]) -> None:
    if SCHEMATIC_PATH.exists():
        SCHEMATIC_PATH.unlink()

    run(
        [
            sys.executable,
            str(SCHEMATIC_TOOL),
            "new-sheet",
            "--title",
            "Candle",
            "--paper",
            "A3",
            str(SCHEMATIC_PATH),
        ],
        cwd=PROJECT_DIR,
    )

    patches: list[dict] = [
        {
            "op": "add-symbol",
            "lib_id": "Connector_Generic:Conn_01x02",
            "ref": "J1",
            "value": "POGO_IN",
            "footprint": "candle:Candle_Pogo_2Pad_2.54mm",
            "at": [35.56, 50.8],
            "rot": 180,
        },
        {"op": "add-wire", "from": {"ref": "J1", "pin": "1"}, "to": {"at": [60.96, 50.8]}},
        {"op": "add-power", "lib_id": "power:VCC", "at": [60.96, 50.8]},
        {"op": "add-wire", "from": {"at": [60.96, 50.8]}, "to": {"at": [68.58, 50.8]}},
        {"op": "add-power", "lib_id": "power:PWR_FLAG", "at": [68.58, 50.8]},
        {"op": "add-wire", "from": {"at": [68.58, 50.8]}, "to": {"at": [76.2, 50.8]}},
        {"op": "add-label", "name": "VCC", "at": [76.2, 50.8]},
        {"op": "add-wire", "from": {"ref": "J1", "pin": "2"}, "to": {"at": [60.96, 48.26]}},
        {"op": "add-power", "lib_id": "power:GND", "at": [60.96, 48.26]},
        {"op": "add-wire", "from": {"at": [60.96, 48.26]}, "to": {"at": [68.58, 48.26]}},
        {"op": "add-power", "lib_id": "power:PWR_FLAG", "at": [68.58, 48.26]},
        {"op": "add-wire", "from": {"at": [68.58, 48.26]}, "to": {"at": [76.2, 48.26]}},
        {"op": "add-label", "name": "GND", "at": [76.2, 48.26]},
        {
            "op": "add-symbol",
            "lib_id": "Mechanical:MountingHole",
            "ref": "H1",
            "value": "MOUNT_HOLE",
            "footprint": "MountingHole:MountingHole_3.2mm_M3",
            "at": [35.56, 106.68],
        },
        {
            "op": "add-symbol",
            "lib_id": "Mechanical:MountingHole",
            "ref": "H2",
            "value": "MOUNT_HOLE",
            "footprint": "MountingHole:MountingHole_3.2mm_M3",
            "at": [35.56, 121.92],
        },
    ]

    branch_layout = schematic_branch_layout()
    for branch in branches:
        led_x, led_y = branch_layout[branch["dref"]]
        res_y = led_y + 15.24
        patches.extend(
            [
                {
                    "op": "add-symbol",
                    "lib_id": "Device:LED",
                    "ref": branch["dref"],
                    "value": branch["led_value"],
                    "footprint": branch["led_fp"],
                    "at": [led_x, led_y],
                    "rot": 90,
                },
                {
                    "op": "add-symbol",
                    "lib_id": "Device:R",
                    "ref": branch["rref"],
                    "value": branch["res_value"],
                    "footprint": branch["res_fp"],
                    "at": [led_x, res_y],
                },
                {"op": "add-wire", "from": {"ref": branch["dref"], "pin": "1"}, "to": {"ref": branch["rref"], "pin": "2"}},
                {"op": "add-wire", "from": {"ref": branch["dref"], "pin": "2"}, "to": {"at": [led_x, led_y - 10.16]}},
                {"op": "add-power", "lib_id": "power:VCC", "at": [led_x, led_y - 10.16]},
                {"op": "add-wire", "from": {"ref": branch["rref"], "pin": "1"}, "to": {"at": [led_x, res_y + 10.16]}},
                {"op": "add-power", "lib_id": "power:GND", "at": [led_x, res_y + 10.16]},
            ]
        )

    payload = {"project_name": PROJECT_NAME, "patches": patches}
    with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False, dir=PROJECT_DIR) as handle:
        json.dump(payload, handle, indent=2)
        patch_path = Path(handle.name)

    try:
        run(
            [
                sys.executable,
                str(SCHEMATIC_TOOL),
                "patch",
                "--execute",
                str(SCHEMATIC_PATH),
                str(patch_path),
            ],
            cwd=PROJECT_DIR,
        )
    finally:
        patch_path.unlink(missing_ok=True)
        Path(str(SCHEMATIC_PATH) + ".bak").unlink(missing_ok=True)


def route_branch(
    board: pcbnew.BOARD,
    nets: dict[str, pcbnew.NETINFO_ITEM],
    led_fp: pcbnew.FOOTPRINT,
    res_fp: pcbnew.FOOTPRINT,
    branch: dict,
) -> None:
    led_cathode = to_mm(pad(led_fp, "1").GetPosition())
    led_anode = to_mm(pad(led_fp, "2").GetPosition())
    res_top = to_mm(pad(res_fp, "1").GetPosition())
    res_bottom = to_mm(pad(res_fp, "2").GetPosition())

    ret_net = nets[branch["net"]]
    add_manhattan(board, ret_net, "F.Cu", led_cathode, res_top, 0.22)

    add_track(board, nets["VCC"], "F.Cu", led_anode, (VCC_RAIL_X, led_anode[1]), 0.28)

    gnd_via_x = round(res_bottom[0] - 0.9, 4) if branch["side"] == "left" else round(res_bottom[0] + 0.9, 4)
    gnd_via = (gnd_via_x, res_bottom[1])
    add_track(board, nets["GND"], "F.Cu", res_bottom, gnd_via, 0.25)
    add_via(board, nets["GND"], gnd_via)


def add_gnd_art(board: pcbnew.BOARD, gnd: pcbnew.NETINFO_ITEM) -> None:
    veins = [
        ((10.0, 103.0), (10.0, 28.0), 0.7, 1.45),
        ((10.0, 96.0), (5.4, 88.0), 0.5, 1.0),
        ((10.0, 90.0), (14.8, 82.0), 0.5, 1.0),
        ((10.0, 80.0), (4.8, 68.0), 0.45, 0.9),
        ((10.0, 74.0), (15.2, 60.0), 0.45, 0.9),
        ((10.0, 60.0), (6.0, 46.0), 0.4, 0.85),
        ((10.0, 54.0), (14.3, 39.0), 0.4, 0.85),
        ((10.0, 42.0), (8.2, 27.0), 0.35, 0.75),
    ]

    for start, end, copper_w, mask_w in veins:
        add_track(board, gnd, "F.Cu", start, end, copper_w)
        add_mask_segment(board, start, end, mask_w)
        if start != (10.0, 103.0):
            add_via(board, gnd, end, drill_mm=0.25, diameter_mm=0.6)

    for via_at in ((10.0, 103.0), (10.0, 28.0)):
        add_via(board, gnd, via_at)


def write_board(branches: list[dict]) -> None:
    board = pcbnew.BOARD()
    configure_board_setup(board)
    add_outline(board)

    net_names = ["VCC", "GND"] + [branch["net"] for branch in branches]
    nets = ensure_nets(board, net_names)

    placed: dict[str, pcbnew.FOOTPRINT] = {
        "J1": load_footprint(board, "candle:Candle_Pogo_2Pad_2.54mm", "J1", "POGO_IN", 10.0, 7.0, 0.0, backside=True),
        "H1": load_footprint(board, "MountingHole:MountingHole_3.2mm_M3", "H1", "MOUNT_HOLE", 4.0, 11.0, 0.0),
        "H2": load_footprint(board, "MountingHole:MountingHole_3.2mm_M3", "H2", "MOUNT_HOLE", 16.0, 11.0, 0.0),
        "U1": load_footprint(board, "Package_SO:SOIC-8_3.9x4.9mm_P1.27mm", "U1", "DECORATIVE", 13.2, 132.0, 90.0),
    }

    for branch in branches:
        placed[branch["dref"]] = load_footprint(
            board,
            branch["led_fp"],
            branch["dref"],
            branch["led_value"],
            branch["led_x"],
            branch["led_y"],
            branch["led_rot"],
        )
        placed[branch["rref"]] = load_footprint(
            board,
            branch["res_fp"],
            branch["rref"],
            branch["res_value"],
            branch["res_x"],
            branch["res_y"],
            branch["res_rot"],
        )

    for fp in placed.values():
        mute_footprint_text(board, fp)

    # Decorative outline only; keep it on the board artwork but out of assembly data.
    placed["U1"].SetDNP(True)
    placed["U1"].SetExcludedFromBOM(True)
    placed["U1"].SetExcludedFromPosFiles(True)

    assign_pad_net(placed["J1"], "1", nets["VCC"])
    assign_pad_net(placed["J1"], "2", nets["GND"])

    for branch in branches:
        assign_pad_net(placed[branch["dref"]], "1", nets[branch["net"]])
        assign_pad_net(placed[branch["dref"]], "2", nets["VCC"])
        assign_pad_net(placed[branch["rref"]], "1", nets[branch["net"]])
        assign_pad_net(placed[branch["rref"]], "2", nets["GND"])

    j1_vcc = to_mm(pad(placed["J1"], "1").GetPosition())
    add_track(board, nets["VCC"], "B.Cu", j1_vcc, (VCC_TRUNK_X, j1_vcc[1]), 0.6)
    add_track(board, nets["VCC"], "B.Cu", (VCC_TRUNK_X, j1_vcc[1]), (VCC_TRUNK_X, VCC_RAIL_Y0), 0.6)
    add_via(board, nets["VCC"], (VCC_TRUNK_X, VCC_RAIL_Y0), drill_mm=0.3, diameter_mm=0.75)
    add_track(board, nets["VCC"], "F.Cu", (VCC_TRUNK_X, VCC_RAIL_Y0), (VCC_RAIL_X, VCC_RAIL_Y0), 0.35)
    add_track(board, nets["VCC"], "F.Cu", (VCC_RAIL_X, VCC_RAIL_Y0), (VCC_RAIL_X, VCC_RAIL_Y1), 0.35)

    for branch in branches:
        route_branch(board, nets, placed[branch["dref"]], placed[branch["rref"]], branch)

    add_gnd_art(board, nets["GND"])
    add_rect_zone(board, nets["GND"], "B.Cu", (0.4, 0.4, 19.6, 214.6), "Back GND")

    add_board_text(board, "D1-D10 / R1-R10", (10.0, 182.0), "B.Silkscreen", size_mm=0.85)
    add_board_text(board, "D11 D12 / R11 R12 / U1", (10.0, 150.0), "B.Silkscreen", size_mm=0.8)
    add_board_text(board, "J1  H1 H2", (10.0, 16.0), "B.Silkscreen", size_mm=0.8)

    pcbnew.SaveBoard(str(BOARD_PATH), board)
    filled_board = pcbnew.LoadBoard(str(BOARD_PATH))
    filler = pcbnew.ZONE_FILLER(filled_board)
    filler.Fill(filled_board.Zones())
    pcbnew.SaveBoard(str(BOARD_PATH), filled_board)


def validate_outputs() -> None:
    OUTPUTS_DIR.mkdir(exist_ok=True)
    erc_path = OUTPUTS_DIR / "candle-erc.json"
    drc_path = OUTPUTS_DIR / "candle-drc.json"

    run(
        [
            str(KICAD_CLI),
            "sch",
            "erc",
            "--format",
            "json",
            "--output",
            str(erc_path),
            str(SCHEMATIC_PATH),
        ],
        cwd=PROJECT_DIR,
    )
    run(
        [
            str(KICAD_CLI),
            "pcb",
            "drc",
            "--format",
            "json",
            "--output",
            str(drc_path),
            str(BOARD_PATH),
        ],
        cwd=PROJECT_DIR,
    )

    erc = json.loads(erc_path.read_text())
    erc_violations = sum(len(sheet.get("violations", [])) for sheet in erc.get("sheets", []))

    drc = json.loads(drc_path.read_text())
    drc_items = drc.get("violations", [])
    drc_unconnected = drc.get("unconnected_items", [])

    print(f"ERC violations: {erc_violations}")
    print(f"DRC violations: {len(drc_items)}")
    print(f"Unconnected items: {len(drc_unconnected)}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--skip-validate", action="store_true")
    args = parser.parse_args()

    branches = branch_defs()
    write_schematic(branches)
    write_board(branches)
    if not args.skip_validate:
        validate_outputs()
    print(f"Generated {SCHEMATIC_PATH.name} and {BOARD_PATH.name}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

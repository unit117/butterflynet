#!/usr/bin/env python3
"""Export fabrication and inspection artifacts for the Candle project."""

from __future__ import annotations

import argparse
import csv
import os
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path


PROJECT_DIR = Path(__file__).resolve().parents[1]
OUTPUTS_DIR = PROJECT_DIR / "outputs"
DOCS_DIR = OUTPUTS_DIR / "docs"
FAB_DIR = OUTPUTS_DIR / "fabrication"
GERBERS_DIR = FAB_DIR / "gerbers"
DRILL_DIR = FAB_DIR / "drill"

SCHEMATIC = PROJECT_DIR / "candle.kicad_sch"
BOARD = PROJECT_DIR / "candle.kicad_pcb"
GENERATOR = PROJECT_DIR / "tools" / "generate_candle.py"

KICAD_CLI = Path("/Applications/KiCad/KiCad.app/Contents/MacOS/kicad-cli")
KICAD_PYTHON = Path(
    "/Applications/KiCad/KiCad.app/Contents/Frameworks/Python.framework/Versions/3.9/bin/python3"
)
KICAD_PYTHONPATH = "/Applications/KiCad/KiCad.app/Contents/Frameworks/python/site-packages"


def run(cmd: list[str], *, env: dict[str, str] | None = None) -> None:
    result = subprocess.run(cmd, cwd=PROJECT_DIR, text=True, capture_output=True, env=env)
    if result.returncode != 0:
        raise RuntimeError(
            f"Command failed: {' '.join(cmd)}\nSTDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}"
        )


def clean_export_dirs() -> None:
    for path in (DOCS_DIR, FAB_DIR):
        if path.exists():
            shutil.rmtree(path)
    DOCS_DIR.mkdir(parents=True, exist_ok=True)
    GERBERS_DIR.mkdir(parents=True, exist_ok=True)
    DRILL_DIR.mkdir(parents=True, exist_ok=True)


def regenerate() -> None:
    env = os.environ.copy()
    env["PYTHONPATH"] = KICAD_PYTHONPATH
    run([str(KICAD_PYTHON), str(GENERATOR)], env=env)


def export_schematic_artifacts() -> None:
    run(
        [
            str(KICAD_CLI),
            "sch",
            "export",
            "netlist",
            "-o",
            str(FAB_DIR / "candle.net"),
            str(SCHEMATIC),
        ]
    )
    run(
        [
            str(KICAD_CLI),
            "sch",
            "export",
            "pdf",
            "-o",
            str(DOCS_DIR / "candle-schematic.pdf"),
            str(SCHEMATIC),
        ]
    )
    run(
        [
            str(KICAD_CLI),
            "sch",
            "export",
            "bom",
            "-o",
            str(FAB_DIR / "candle-bom-raw.csv"),
            "--fields",
            "Reference,Value,Footprint,QUANTITY",
            "--labels",
            "Refs,Value,Footprint,Qty",
            "--group-by",
            "Value,Footprint",
            str(SCHEMATIC),
        ]
    )


def write_curated_bom() -> None:
    rows = [
        {
            "Refs": "D1-D10",
            "Value": "WW_2700K",
            "Footprint": "LED_SMD:LED_0805_2012Metric",
            "Qty": "10",
            "Notes": "Top flame LEDs",
        },
        {
            "Refs": "D11,D12",
            "Value": "WW_2700K",
            "Footprint": "LED_SMD:LED_0603_1608Metric",
            "Qty": "2",
            "Notes": "Mid decorative glow LEDs",
        },
        {
            "Refs": "R1-R10",
            "Value": "300R",
            "Footprint": "Resistor_SMD:R_0805_2012Metric",
            "Qty": "10",
            "Notes": "Top LED current limit resistors",
        },
        {
            "Refs": "R11,R12",
            "Value": "1k",
            "Footprint": "Resistor_SMD:R_0603_1608Metric",
            "Qty": "2",
            "Notes": "Mid glow current limit resistors",
        },
    ]
    out_path = FAB_DIR / "candle-assembly-bom.csv"
    with out_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["Refs", "Value", "Footprint", "Qty", "Notes"])
        writer.writeheader()
        writer.writerows(rows)


def write_assembly_notes() -> None:
    notes = """# Candle Assembly Notes

- `U1` is decorative only. It is marked DNP on the PCB and is excluded from placement output.
- `J1` is an integrated copper landing pattern for spring pogo pins in the base, not a separate PCB-mounted connector.
- `H1` and `H2` are mechanical clamp holes for the sleeve interface and are not assembly-line components.
- `candle-pos.csv` includes only populated SMD parts.
"""
    (FAB_DIR / "candle-assembly-notes.md").write_text(notes, encoding="utf-8")


def export_board_artifacts() -> None:
    run(
        [
            str(KICAD_CLI),
            "pcb",
            "export",
            "pdf",
            "--mode-single",
            "--check-zones",
            "-l",
            "F.Cu,F.Mask,F.SilkS,Edge.Cuts",
            "-o",
            str(DOCS_DIR / "candle-board-front.pdf"),
            str(BOARD),
        ]
    )
    run(
        [
            str(KICAD_CLI),
            "pcb",
            "export",
            "pdf",
            "--mode-single",
            "--check-zones",
            "--mirror",
            "-l",
            "B.Cu,B.Mask,B.SilkS,Edge.Cuts",
            "-o",
            str(DOCS_DIR / "candle-board-back.pdf"),
            str(BOARD),
        ]
    )
    run(
        [
            str(KICAD_CLI),
            "pcb",
            "export",
            "gerbers",
            "--check-zones",
            "--exclude-refdes",
            "--exclude-value",
            "--subtract-soldermask",
            "-l",
            "F.Cu,B.Cu,F.Mask,B.Mask,F.SilkS,B.SilkS,Edge.Cuts",
            "-o",
            str(GERBERS_DIR),
            str(BOARD),
        ]
    )
    run(
        [
            str(KICAD_CLI),
            "pcb",
            "export",
            "drill",
            "--format",
            "excellon",
            "--excellon-separate-th",
            "--generate-map",
            "--map-format",
            "pdf",
            "--generate-report",
            "--report-path",
            str(DRILL_DIR / "candle-drill-report.rpt"),
            "-o",
            str(DRILL_DIR),
            str(BOARD),
        ]
    )
    run(
        [
            str(KICAD_CLI),
            "pcb",
            "export",
            "pos",
            "-o",
            str(FAB_DIR / "candle-pos.csv"),
            "--format",
            "csv",
            "--units",
            "mm",
            "--exclude-fp-th",
            "--exclude-dnp",
            str(BOARD),
        ]
    )


def package_bundle() -> None:
    bundle_path = FAB_DIR / "candle-fabrication-bundle.zip"
    with zipfile.ZipFile(bundle_path, "w", compression=zipfile.ZIP_DEFLATED) as bundle:
        for path in sorted(FAB_DIR.rglob("*")):
            if path == bundle_path or path.is_dir():
                continue
            bundle.write(path, path.relative_to(FAB_DIR))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--skip-generate", action="store_true")
    args = parser.parse_args()

    clean_export_dirs()
    if not args.skip_generate:
        regenerate()

    export_schematic_artifacts()
    write_curated_bom()
    write_assembly_notes()
    export_board_artifacts()
    package_bundle()

    print(f"Wrote docs to {DOCS_DIR}")
    print(f"Wrote fabrication bundle to {FAB_DIR}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
